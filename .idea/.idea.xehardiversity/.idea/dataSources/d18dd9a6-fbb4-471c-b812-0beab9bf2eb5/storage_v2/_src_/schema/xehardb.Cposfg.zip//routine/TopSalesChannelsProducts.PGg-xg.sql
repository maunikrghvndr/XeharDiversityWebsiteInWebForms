CREATE PROCEDURE TopSalesChannelsProducts(IN odate DATE, IN salesid INT)
  BEGIN
	Select  prod.ProductName as ordname, sum(prod.profit) as ordprofit 
		from orders as orde 
			join (
				Select p.ProductName, selling.oid as seoid, p.vid as pvid,p.VendorCost,selling.sellingprice,selling.pid as ppid,(selling.sellingprice-VendorCost*selling.quantity)as profit 
					from products as p 
						Join (
							SELECT os.oid ,os.pid , os.quantity,(Quantity*UnitPrice- UnitPrice*Quantity*ifnull(Discount,0) )  as sellingprice 
								from ordersdetails as os , orders as ord 
									where ord.OrderDate >=odate 
										and os.oid=ord.oid) selling 
											where p.pid=selling.pid )prod
												where orde.oid =prod.seoid 
													and orde.scid=salesid 
														group by prod.ppid ;



END;

