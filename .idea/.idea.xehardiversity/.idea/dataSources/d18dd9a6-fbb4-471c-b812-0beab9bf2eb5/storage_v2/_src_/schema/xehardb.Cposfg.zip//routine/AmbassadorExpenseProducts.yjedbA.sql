CREATE PROCEDURE AmbassadorExpenseProducts(IN AmbsID INT)
  BEGIN
Select  p.ProductName as pname,  sub.AmountSpend from products as p   join   (SELECT os.pid as pidd, ord.OrderDate, ord.Aid as oaid  , os.OID,  (Quantity*UnitPrice- UnitPrice*Quantity*ifnull(Discount,0) )  as AmountSpend
								from ordersdetails as os , orders as ord 
									where  os.oid=ord.oid and ord.DiscountCode = 'free12' and ord.aid=AmbsID  group by os.pid  ) sub  where p.pid= sub.pidd;
END;

