CREATE PROCEDURE insertlocation()
  BEGIN
declare i int default 10;
#declare y int default 1;
#declare x int default 1;

while i<95 do
#while x<b do
#while y<c do

insert into xehardb.colors (colorCode) values (concat(i,'00'));
#set y=y+1;
#end while;
#set y=1;
#set x=x+1;
#end while;
#set x=1;
set i=i+1;
end while;

END;

