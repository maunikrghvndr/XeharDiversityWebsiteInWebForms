CREATE PROCEDURE TopVendorProductsSold(IN odate DATE, IN vendorID INT)
  BEGIN
   select sub.pids as PID,  p.ProductName , sub.TotalSold 
			from  products as p  
					join (select os.pid as pids, sum(os.Quantity) as TotalSold  
						from  ordersdetails as os , orders as o 
							where  os.OID=o.OID and o.OrderDate >= odate group by pids order by TotalSold  ) sub 
								where p.pid =sub.pids and p.vid= vendorID
									group by pid;
END;

