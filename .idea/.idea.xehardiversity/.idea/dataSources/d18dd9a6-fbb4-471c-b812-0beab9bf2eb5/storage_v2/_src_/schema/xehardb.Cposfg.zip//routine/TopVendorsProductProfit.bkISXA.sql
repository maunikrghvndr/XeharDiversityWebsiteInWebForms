CREATE PROCEDURE TopVendorsProductProfit(IN odate DATE, IN vendorID INT)
  BEGIN
						Select p.ProductName,sum(selling.sellingprice-VendorCost*selling.quantity)as profit 
								from products as p 
									Join (
										SELECT os.oid ,os.pid , os.quantity,(Quantity*UnitPrice- UnitPrice*Quantity*ifnull(Discount,0) )  as sellingprice 
											from ordersdetails as os , orders as ord 
												where ord.OrderDate >=odate and os.oid=ord.oid) selling 
													where p.pid=selling.pid and p.vid= vendorID group by p.pid;
END;

