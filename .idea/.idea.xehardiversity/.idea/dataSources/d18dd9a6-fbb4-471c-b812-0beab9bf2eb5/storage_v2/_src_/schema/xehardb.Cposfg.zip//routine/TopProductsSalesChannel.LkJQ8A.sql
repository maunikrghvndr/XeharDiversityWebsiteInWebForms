CREATE PROCEDURE TopProductsSalesChannel(IN odate DATETIME, IN productID INT)
  BEGIN
Select final.pnames, s.Name , final.totalsum
from saleschannels as s  
	join(select  sub2.oids as suboids ,sub2.pid as pids, sub2.pname as pnames, o.scid as odscid, sum(sub2.tsold) as TotalSum 
		from orders as o  
			join(select sub.osid as oids, sub.pid as PID, p.ProductName as pname, sub.TotalSold as tsold 
				from  products as p   
					join ( select os.pid as pid,os.oid as osid ,os.Quantity as TotalSold  
						from  ordersdetails as os , orders as o where  os.OID=o.OID and o.OrderDate >= odate ) sub 
			where p.pid =sub.pid )sub2 
	where  o.oid= sub2.oids  and pid=productID group by scid  )final   
 where s.scid= final.odscid;


END;

