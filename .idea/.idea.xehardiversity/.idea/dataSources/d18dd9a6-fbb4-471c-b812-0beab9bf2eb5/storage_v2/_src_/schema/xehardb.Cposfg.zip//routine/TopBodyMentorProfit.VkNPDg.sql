CREATE PROCEDURE TopBodyMentorProfit(IN odate DATETIME)
  BEGIN
select sc.scid, sc.name, (final.fprofit-final.fprofit*ifnull(sc.SCRates,0)) as TotalProfit
	from saleschannels as sc 
		join (
			Select o.scid as fscid ,
				sum(pro.profit)as fprofit
					from orders as o  
						join(
							Select selling.oid as prooid, p.vid,p.VendorCost,selling.sellingprice,selling.pid,sum(selling.sellingprice-VendorCost*selling.quantity)as profit 
								from products as p 
									Join (
										SELECT os.oid ,os.pid , os.quantity,(Quantity*UnitPrice- UnitPrice*Quantity*ifnull(Discount,0) )  as sellingprice 
											from ordersdetails as os , orders as ord 
												where ord.OrderDate >=odate and os.oid=ord.oid) selling 
													where p.pid=selling.pid group by selling.oid) pro 
														where o.oid =pro.prooid group by o.scid) final 
															where sc.scid=final.fscid and sc.status='BodyMentor';
END;

