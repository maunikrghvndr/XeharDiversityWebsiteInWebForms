CREATE PROCEDURE TopProducts(IN odate DATE)
  BEGIN
		select sub.pid as PID, p.ProductName , sub.TotalSold 
			from  products as p   
				join ( 
					select os.pid as pid, sum(os.Quantity) as TotalSold  
						from  ordersdetails as os , orders as o 
							where  os.OID=o.OID and o.OrderDate >= odate group by pid ) sub 
								where p.pid =sub.pid 
									order by sub.TotalSold desc limit 5
;
END;

