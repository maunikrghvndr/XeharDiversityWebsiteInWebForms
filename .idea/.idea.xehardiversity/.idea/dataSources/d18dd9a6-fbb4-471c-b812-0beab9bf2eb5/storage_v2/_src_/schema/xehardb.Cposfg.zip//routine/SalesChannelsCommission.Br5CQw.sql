CREATE PROCEDURE SalesChannelsCommission(IN SalesID INT)
  BEGIN
select sc.scid, sc.name,  (final.fprofit*sc.SCRates)  as commission
	from saleschannels as sc 
		join (
			Select o.scid as fscid ,
				sum(pro.profit)as fprofit
					from orders as o  
						join(
							Select selling.oid as prooid,sum(selling.sellingprice)as profit 
								from products as p 
									Join (
										SELECT os.oid ,os.pid , os.quantity,(Quantity*UnitPrice- UnitPrice*Quantity*ifnull(Discount,0) )  as sellingprice 
											from ordersdetails as os , orders as ord 
												where  os.oid=ord.oid and ord.scid=SalesID) selling 
													where p.pid=selling.pid group by selling.oid) pro 
														where o.oid =pro.prooid group by o.scid) final 
															where sc.scid=final.fscid;
END;

