CREATE PROCEDURE ProfitFromAmbassador(IN AmbsID INT)
  BEGIN
Select sub.sdate as orderdate ,am.DiscountCode,sub.pname, am.Name, sum((sub.sold -sub.sold*am.discountpercentage)-(sub.sss -sub.sss*am.discountpercentage)*am.commision )as revenue 
 from Ambassadors as am 
    join (
        Select selling.odate as sdate, selling.Discount as di, selling.oaid as sellaid, p.ProductName as pname, selling.oid as seoid, p.vid as pvid,p.VendorCost,selling.sellingprice as sss,(selling.sellingprice-VendorCost*selling.quantity) as sold ,selling.pid as ppid
					from products as p 
						Join (
							SELECT ord.OrderDate as odate ,ord.Aid as oaid, ord.DiscountCode as discount,  os.oid ,os.pid , os.quantity,(Quantity*UnitPrice- UnitPrice*Quantity*ifnull(Discount,0) )  as sellingprice 
								from ordersdetails as os , orders as ord 
									where  os.oid=ord.oid and ord.DiscountCode != 'free12' and ord.aid=AmbsID ) selling 
											where p.pid=selling.pid) sub
                                              where am.DiscountCode = sub.di group by am.aid;
END;

