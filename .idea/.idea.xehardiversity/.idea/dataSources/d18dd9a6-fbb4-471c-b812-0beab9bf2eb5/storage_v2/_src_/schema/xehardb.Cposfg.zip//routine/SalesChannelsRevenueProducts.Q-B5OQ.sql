CREATE PROCEDURE SalesChannelsRevenueProducts(IN SalesID INT)
  BEGIN
Select  prod.ProductName as ordname, sum(prod.profit) as revenue 
		from orders as orde 
			join (
				Select p.ProductName, selling.oid as seoid, p.vid as pvid,p.VendorCost,selling.sellingprice,selling.pid as ppid,(selling.sellingprice)as profit 
					from products as p 
						Join (
							SELECT os.oid ,os.pid , os.quantity,(Quantity*UnitPrice- UnitPrice*Quantity*ifnull(Discount,0) )  as sellingprice 
								from ordersdetails as os , orders as ord 
									where  os.oid=ord.oid) selling 
											where p.pid=selling.pid )prod
												where orde.oid =prod.seoid 
													and orde.scid=SalesID
														group by prod.ppid ;
END;

