CREATE PROCEDURE ProfitFromProduct(IN ProductID INT)
  BEGIN
select p.pid,p.productname, ifnull(round(sum(almost-ifnull(p.vendorcost,0)),2 ),0) as total 
	from products as p 
		join 
			(select sub2.spid as spid2, sub2.soid as soid2,sub2.sscid , sub2.said, (sub2.selling -sub2.selling*ifnull(sc.scrates,0))as almost 
				from saleschannels as sc 
					join 
						(select sub.subpid as spid,sub.suboid as soid,sub.subscid as sscid,sub.subaid as said,(sub.sellingprice-sub.sellingprice*ifnull(am.Commision,0)-sub.sellingPrice*ifnull(am.discountPercentage,0)) as selling
							from ambassadors as am right 
								join 
									(select os.pid as subpid , o.oid as suboid , o.scid as subscid, o.aid as subaid, o.discountcode as subdisc, (os.Quantity*os.UnitPrice- os.UnitPrice*os.Quantity*ifnull(os.Discount,0) )  as sellingprice  
										from orders as o ,ordersdetails as os 
											where os.oid=o.oid and os.pid=ProductID and ifnull(o.DiscountCode,0) <> 'free12')sub  
												on am.aid=sub.subaid)sub2 
													where sc.scid=sub2.sscid) sub3 
															where p.pid=sub3.spid2;
END;

