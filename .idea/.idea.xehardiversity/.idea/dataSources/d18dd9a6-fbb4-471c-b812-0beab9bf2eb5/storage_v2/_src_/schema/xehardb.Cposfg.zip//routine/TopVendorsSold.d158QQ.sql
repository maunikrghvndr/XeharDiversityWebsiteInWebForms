CREATE PROCEDURE TopVendorsSold(IN odate DATE)
  BEGIN
select p.vid , v.Name , sub.TotalSold 
			from  products as p , vendors as v  
				join ( 
					select os.pid as pid, sum(os.Quantity) as TotalSold  
						from  ordersdetails as os , orders as o 
							where  os.OID=o.OID and o.OrderDate >= odate group by pid ) sub 
								where p.pid =sub.pid and v.vid= p.vid group by p.vid
									order by sub.TotalSold desc limit 5;
END;

