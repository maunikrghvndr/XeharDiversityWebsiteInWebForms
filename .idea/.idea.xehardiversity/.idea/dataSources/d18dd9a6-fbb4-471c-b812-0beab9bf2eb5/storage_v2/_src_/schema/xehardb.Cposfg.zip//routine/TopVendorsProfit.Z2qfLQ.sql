CREATE PROCEDURE TopVendorsProfit(IN odate DATE)
  BEGIN
 Select  p.vid,v.Name,sum(selling.sellingprice-VendorCost*selling.quantity)as profit 
								from products as p , vendors as v
									Join (
										SELECT os.oid ,os.pid , os.quantity,(Quantity*UnitPrice- UnitPrice*Quantity*ifnull(Discount,0) )  as sellingprice 
											from ordersdetails as os , orders as ord 
												where ord.OrderDate >=odate and os.oid=ord.oid) selling 
													where p.pid=selling.pid and v.vid= p.vid group by p.vid  order by profit desc limit 5 ;
END;

