CREATE PROCEDURE SalesChannelRevenue(IN SalesID INT)
  BEGIN
select final.pdate, sc.scid, sc.name, sum(final.fprofit) as revenue
	from saleschannels as sc 
		join (
			Select pro.sdate as pdate , o.scid as fscid ,
				pro.profit as fprofit
					from orders as o  
						join(
							Select selling.odate as sdate ,selling.oid as prooid, selling.sellingprice as profit 
								from products as p 
									Join (
										SELECT ord.OrderDate as odate , os.oid ,os.pid , os.quantity,(Quantity*UnitPrice- UnitPrice*Quantity*ifnull(Discount,0) )  as sellingprice 
											from ordersdetails as os , orders as ord 
												where  os.oid=ord.oid and ord.scid=SalesID) selling 
													where p.pid=selling.pid ) pro 
														where o.oid =pro.prooid ) final 
															where sc.scid=final.fscid group by final.pdate order by final.pdate  ;
END;

