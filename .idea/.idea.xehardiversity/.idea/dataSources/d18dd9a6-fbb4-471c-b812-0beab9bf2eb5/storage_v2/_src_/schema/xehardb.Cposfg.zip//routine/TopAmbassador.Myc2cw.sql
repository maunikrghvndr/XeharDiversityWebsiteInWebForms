CREATE PROCEDURE TopAmbassador(IN odate DATE)
  BEGIN
Select am.aid, am.Name, sum(sub.sold -sub.sold*am.discountpercentage) as revenue 
 from Ambassadors as am 
    join (
        Select selling.Discount as di, selling.oaid as sellaid, p.ProductName as pname, selling.oid as seoid, p.vid as pvid,p.VendorCost,selling.sellingprice as sold ,selling.pid as ppid
					from products as p 
						Join (
							SELECT ord.Aid as oaid, ord.DiscountCode as discount,  os.oid ,os.pid , os.quantity,(Quantity*UnitPrice- UnitPrice*Quantity*ifnull(Discount,0) )  as sellingprice 
								from ordersdetails as os , orders as ord 
									where ord.OrderDate >=odate  
										and os.oid=ord.oid and ord.DiscountCode != 'free12'   ) selling 
											where p.pid=selling.pid) sub
                                              where am.DiscountCode = sub.di group by am.aid  order by revenue desc limit 5;
END;

